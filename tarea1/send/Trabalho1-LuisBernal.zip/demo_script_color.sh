mkdir results_color

python3 color_change.py -e sepia -s results_color/baboon_sepia.png baboon_color.png 
python3 color_change.py -e gray -s results_color/baboon_gray.png baboon_color.png 